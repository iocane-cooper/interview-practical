﻿Public Class Troubleshooting
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try

            For i As Integer = 97 To 122
                Dim ltr As String = Chr(i).ToString
                ddlAlphabet.Items.Add(New ListItem(ltr, ltr))
            Next

            Session("LetterList") = New List(Of String)


        Catch ex As Exception
            System.Diagnostics.Debug.WriteLine(ex.Message)
        End Try
    End Sub


    Protected Sub btnAddToList_Click(sender As Object, e As EventArgs)
        Try
            Dim theList As List(Of String) = TryCast(Session("LetterList"), List(Of String))

            If theList IsNot Nothing Then
                theList.Add(ddlAlphabet.SelectedValue)
                For Each item As String In theList
                    Dim r As New TableRow
                    r.Cells.Add(New TableCell With {.Text = item})
                    tblItems.Rows.Add(r)
                Next
            End If


        Catch ex As Exception
            System.Diagnostics.Debug.WriteLine(ex.Message)
        End Try

    End Sub




End Class